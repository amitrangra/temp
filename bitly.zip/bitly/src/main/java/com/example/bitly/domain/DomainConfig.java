package com.example.bitly.domain;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.bitly.adapter.ShortnerEndpoint;

@Configuration
public class DomainConfig {

    @Bean
    public ShortnerService shortnerService() {
        return new ShortnerService();
    }
}
