package com.example.bitly.adapter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.bitly.domain.ShortnerService;

@Configuration
public class AdapterConfig {

    @Bean
    public ShortnerEndpoint shortnerEndpoint(ShortnerService shortnerService) {
        return new ShortnerEndpoint(shortnerService);
    }
}
