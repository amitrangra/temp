package com.example.bitly.domain;

import static java.lang.String.format;

import java.util.HashMap;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;

public class ShortnerService {
    private HashMap<String, String> codes;

    public String shorten(String url) {
        String code = getCode();
        updateMap(code, url);
        return format("http://localhost:8080/%s", code);
    }

    public String get(String code) {
        return codes != null && codes.containsKey(code)? codes.get(code): "Error: Invalid short url";
    }

    private String getCode() {
        return RandomStringUtils.randomAlphanumeric(7);
    }

    @Cacheable("map")
    public HashMap<String, String> getMap() {
        codes = new HashMap<>();
        return codes;
    }

    @CachePut(value = "map")
    public HashMap<String, String> updateMap(String code, String url) {
        getMap().put(code, url);
        return codes;
    }
}
