package com.example.bitly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;

import com.example.bitly.adapter.AdapterConfig;
import com.example.bitly.domain.DomainConfig;

@SpringBootConfiguration
@EnableAutoConfiguration
@Import({AdapterConfig.class, DomainConfig.class})
@EnableCaching
public class BitlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitlyApplication.class, args);
	}

}
