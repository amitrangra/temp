package com.example.bitly.adapter;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bitly.domain.ShortnerService;

@RestController
public class ShortnerEndpoint {
    private ShortnerService shortnerService;

    public ShortnerEndpoint(ShortnerService shortnerService) {
        this.shortnerService = shortnerService;
    }

    @GetMapping("/short")
    @ResponseBody
    public String shorten(@RequestParam("url") String url) {
        return shortnerService.shorten(url);
    }

    @GetMapping("/{code}")
    @ResponseBody
    public String get(@PathVariable String code) {
        return shortnerService.get(code);
    }//zuwa.omigie@shopify.com
}
